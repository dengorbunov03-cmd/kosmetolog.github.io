/* Визуальная проверка лендинга: реальный Chrome, скриншоты ключевых зон,
   поиск наложений элементов (overlap) и консольных ошибок. */
const puppeteer = require('puppeteer');
const path = require('path');
const http = require('http');

(async () => {
  // поднять сервер страницы нельзя в этом же процессе? можно — простая статика
  const fs = require('fs');
  const server = http.createServer((req, res) => {
    let u = req.url.split('?')[0];
    if (u === '/favicon.ico') { res.writeHead(204); return res.end(); }
    let f = path.join(__dirname, decodeURIComponent(u));
    if (f.endsWith('/')) f += 'index.html';
    fs.readFile(f, (e, d) => {
      if (e) { res.writeHead(404); return res.end('nf'); }
      res.writeHead(200, { 'Content-Type': f.endsWith('.css') ? 'text/css' : f.endsWith('.js') ? 'text/javascript' : f.endsWith('.jpg') ? 'image/jpeg' : 'text/html; charset=utf-8' });
      res.end(d);
    });
  });
  await new Promise(r => server.listen(8811, '127.0.0.1', r));

  const browser = await puppeteer.launch({
    headless: 'new',
    args: ['--no-sandbox', '--disable-setuid-sandbox', '--disable-dev-shm-usage'],
  });
  const errors = [];
  const page = await browser.newPage();
  page.on('pageerror', e => errors.push('pageerror: ' + e.message));
  page.on('console', m => { if (m.type() === 'error') errors.push('console: ' + m.text()); });

  // ---------- DESKTOP ----------
  await page.setViewport({ width: 1360, height: 900, deviceScaleFactor: 1 });
  await page.goto('http://127.0.0.1:8811/', { waitUntil: 'networkidle0' });
  await new Promise(r => setTimeout(r, 700));

  // 1) hero + шапка
  await page.screenshot({ path: 'shot-desktop-hero.png' });

  // 2) услуги (все карточки с чипами скидки)
  await page.evaluate(() => document.querySelector('#services').scrollIntoView());
  await new Promise(r => setTimeout(r, 600));
  await page.screenshot({ path: 'shot-desktop-services.png' });

  // 3) услуги в ховере (был баг «на ведении растягивается»)
  await page.hover('.s-card');
  await new Promise(r => setTimeout(r, 600));
  await page.screenshot({ path: 'shot-desktop-services-hover.png' });

  // 4) до/после + bellarti
  await page.evaluate(() => document.querySelector('#results').scrollIntoView());
  await new Promise(r => setTimeout(r, 600));
  await page.screenshot({ path: 'shot-desktop-results.png' });

  // 5) форма
  await page.evaluate(() => document.querySelector('#booking').scrollIntoView());
  await new Promise(r => setTimeout(r, 600));
  await page.screenshot({ path: 'shot-desktop-booking.png' });

  // --- overlap-детектор: заголовок/кнопка/чип не должны пересекаться ---
  const overlapReport = await page.evaluate(() => {
    const out = [];
    document.querySelectorAll('.s-card').forEach(card => {
      const a = card.querySelector('.s-card__body h3').getBoundingClientRect();
      const d = card.querySelector('.disc-chip').getBoundingClientRect();
      const btn = card.querySelector('.s-card__btn').getBoundingClientRect();
      const price = card.querySelector('.s-card__price').getBoundingClientRect();
      const hit = (r1, r2) => !(r1.right <= r2.left + 1 || r2.right <= r1.left + 1 || r1.bottom <= r2.top + 1 || r2.bottom <= r1.top + 1);
      if (hit(a, d)) out.push('H3 x DISC overlap');
      if (hit(d, btn)) out.push('DISC x BTN overlap');
      if (hit(price, d)) out.push('PRICE x DISC overlap');
      // картинка не вылезает за медиа?
      const media = card.querySelector('.s-card__media');
      const mr = media.getBoundingClientRect();
      const img = media.querySelector('img');
      const ir = img.getBoundingClientRect();
      if (ir.width > mr.width + 1 || ir.height > mr.height + 1) out.push('IMG bigger than media (растянута)');
    });
    return out;
  });

  // --- скроллить ли горизонтально? (признак «съехало») ---
  const hScroll = await page.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth);

  // ---------- MOBILE ----------
  await page.setViewport({ width: 390, height: 844, deviceScaleFactor: 2, isMobile: true, hasTouch: true });
  await page.goto('http://127.0.0.1:8811/', { waitUntil: 'networkidle0' });
  await new Promise(r => setTimeout(r, 700));
  await page.screenshot({ path: 'shot-mobile-hero.png' });
  await page.evaluate(() => document.querySelector('#services').scrollIntoView());
  await new Promise(r => setTimeout(r, 600));
  await page.screenshot({ path: 'shot-mobile-services.png' });
  const hScrollMobile = await page.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth);
  const overlapMobile = await page.evaluate(() => {
    const out = [];
    document.querySelectorAll('.s-card').forEach(card => {
      const d = card.querySelector('.disc-chip').getBoundingClientRect();
      const btn = card.querySelector('.s-card__btn').getBoundingClientRect();
      const hit = (r1, r2) => !(r1.right <= r2.left + 1 || r2.right <= r1.left + 1 || r1.bottom <= r2.top + 1 || r2.bottom <= r1.top + 1);
      if (hit(d, btn)) out.push('MOBILE DISC x BTN overlap');
    });
    return out;
  });

  console.log('JS errors:', errors.length ? errors : 'none');
  console.log('Desktop overlaps:', overlapReport.length ? overlapReport : 'none');
  console.log('Desktop horizontal overflow px:', hScroll);
  console.log('Mobile overlaps:', overlapMobile.length ? overlapMobile : 'none');
  console.log('Mobile horizontal overflow px:', hScrollMobile);

  await browser.close();
  server.close();
  const bad = errors.length || overlapReport.length || overlapMobile.length || hScroll > 1 || hScrollMobile > 1;
  process.exit(bad ? 1 : 0);
})().catch(e => { console.error('RUNNER FAIL:', e.message); process.exit(2); });
