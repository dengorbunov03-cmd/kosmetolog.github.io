/* Интеграционный тест лендинга: гоняем РЕАЛЬНЫЙ index.html в jsdom.
   Единственные шимы — scrollIntoView (нет в jsdom) и перехват window.open. */
const { JSDOM } = require('jsdom');
const path = require('path');
const assert = require('assert');

(async () => {
  let opened = [];
  const dom = await JSDOM.fromFile(path.join(__dirname, 'index.html'), {
    runScripts: 'dangerously',
    pretendToBeVisual: true,
    url: 'http://localhost/',
    beforeParse(window) {
      window.Element.prototype.scrollIntoView = function () {};
      window.open = (url) => { opened.push(url); return null; };
      window.HTMLElement.prototype.focus = function () {};
    },
  });
  const { window } = dom;
  const doc = window.document;
  await new Promise(r => window.addEventListener('load', r));
  // дождаться выполнения inline-IIFE страницы
  await new Promise(r => setTimeout(r, 50));

  const $ = (s) => doc.querySelector(s);
  const fire = (el, type) => el.dispatchEvent(new window.Event(type, { bubbles: true }));
  let pass = 0;
  const ok = (cond, msg) => { assert.ok(cond, msg); console.log('  ✓', msg); pass++; };

  console.log('TEST 1: быстрые кнопки (шапка/hero) получают диплинк MAX');
  const quick = doc.querySelector('[data-deeplink="quick"]');
  ok(/^https:\/\/max\.ru\/:share\?text=/.test(quick.getAttribute('href')), 'href = ' + quick.getAttribute('href').slice(0, 60) + '…');
  ok(quick.getAttribute('target') === '_blank', 'открывается в новой вкладке');

  console.log('TEST 2: маска телефона');
  const phone = $('#phone');
  phone.value = '9953413404'; fire(phone, 'input');
  ok(phone.value === '+7 (995) 341-34-04', '«9953413404» → ' + phone.value);
  phone.value = '+799534134'; fire(phone, 'input');
  ok(phone.value === '+7 (995) 341-34', 'недономер доформатирован: ' + phone.value);
  phone.value = '89991234567'; fire(phone, 'input');
  ok(phone.value === '+7 (999) 123-45-67', 'восьёрка → +7: ' + phone.value);
  phone.value = '9953413404'; fire(phone, 'input'); // вернём валидный

  console.log('TEST 3: незаполненная форма НЕ открывает MAX, подсвечивает поля');
  opened = [];
  $('#submitBtn').click();
  ok(opened.length === 0, 'window.open не вызван');
  ok(doc.querySelectorAll('.field.invalid').length >= 2, 'подсвечено обязательных полей: ' + doc.querySelectorAll('.field.invalid').length);
  ok($('#toast').classList.contains('is-visible'), 'тост-предупреждение показано');

  console.log('TEST 4: валидная отправка → диплинк с текстом заявки');
  $('#name').value = 'Мария“ & /тест'; fire($('#name'), 'input');
  const sel = $('#service');
  sel.value = 'Биоревитализация'; fire(sel, 'change');
  const d = new Date(Date.now() + 3 * 864e5);
  $('#date').value = d.toISOString().slice(0, 10); fire($('#date'), 'input');
  $('#time').value = '16:30'; fire($('#time'), 'input');
  $('#comment').value = 'нужно до 17:00'; fire($('#comment'), 'input');
  opened = [];
  $('#toast').classList.remove('is-visible');
  $('#submitBtn').click();
  await new Promise(r => setTimeout(r, 30));
  ok(opened.length === 1, 'MAX открыт ровно 1 раз');
  const url = new window.URL(opened[0]);
  ok(url.origin + url.pathname === 'https://max.ru/:share', 'базовый адрес ' + url.origin + url.pathname);
  const msg = url.searchParams.get('text'); /* URLSearchParams уже декодирует */
  console.log('    текст заявки:', JSON.stringify(msg));
  ok(msg.startsWith('Здравствуйте! Хочу записаться.'), 'начало сообщения');
  ok(msg.includes('Имя: Мария“ & /тест'), 'имя передано (кавычки/спецсимволы целы)');
  ok(msg.includes('Телефон: +7 (995) 341-34-04'), 'телефон');
  ok(msg.includes('Услуга: Биоревитализация'), 'услуга');
  ok(/\d+ \S+, 16:30/.test(msg), 'дата/время человекочитаемо');
  ok(msg.includes('Комментарий: нужно до 17:00'), 'комментарий');
  ok($('#toastText').textContent === 'Спасибо! Сейчас откроется MAX для отправки заявки', 'текст тоста по ТЗ');
  ok($('#formOk').classList.contains('is-visible'), 'инлайн-подтверждение показано');

  console.log('TEST 5: дата в прошлом → блок');
  $('#date').value = '2020-01-01'; fire($('#date'), 'input');
  opened = [];
  $('#submitBtn').click();
  ok(opened.length === 0 && doc.querySelectorAll('.field.invalid').length >= 1, 'прошлая дата не проходит');
  $('#date').value = d.toISOString().slice(0, 10); fire($('#date'), 'input');

  console.log('TEST 6: кнопка услуги подставляет услугу и не открывает MAX сама');
  doc.querySelectorAll('.s-card__btn')[4].click(); // «Коррекция губ»
  ok($('#service').value === 'Коррекция губ', 'услуга выбрана из карточки: ' + $('#service').value);

  console.log('TEST 7: href главной кнопки живьём обновляется при вводе');
  fire($('#name'), 'input');
  const hrefNow = $('#submitBtn').getAttribute('href');
  ok(decodeURIComponent(hrefNow).includes('Имя: Мария'), 'href синхронизирован с формой');

  console.log('TEST 8: дублирующая кнопка «Написать в MAX» — чистая ссылка профиля');
  const dup = doc.querySelector('.form__alt a[href^="https://max.ru/u/"]');
  ok(dup && dup.getAttribute('href') === 'https://max.ru/u/f9LHodD0cOKSmE31Vd8WuA9E1p3PX99Kn2_SOFWnVfKsDGmGxriQ_aRmXCw', 'href = профиль без ?text=');

  console.log('TEST 9: правки пользователя');
  const body = doc.body.textContent;
  ok(!/без ботов/.test(body), 'подписи «без ботов» в футере больше нет');
  ok(!/Атмосфера и процессы/.test(body), 'заголовка «Атмосфера и процессы» нет');
  ok(!doc.querySelector('#gallery') && !doc.querySelector('#lightbox'), 'секции «Галерея» и лайтбокса больше нет');
  ok(!/href="#gallery"/.test(doc.body.innerHTML.replace(/\s+/g,' ')), 'ссылок на галерею в меню нет');
  ok(doc.querySelector('.hero__title').textContent.trim() === 'Красота. Уверенность. ТЫ.', 'слоган в hero: «' + doc.querySelector('.hero__title').textContent.trim() + '»');
  ok(!/ЗАМЕНИТЕ|README-photos|замените/.test(body), 'инструкций по замене файлов в видимом тексте нет');

  console.log('TEST 10: скидка 30%');
  const discs = doc.querySelectorAll('.disc-chip');
  ok(discs.length === 6, 'бейдж скидки на каждой из 6 карточек');
  ok([...discs].every(el => el.textContent.trim() === 'Скидка 30%'), 'текст бейджей подставлен JS: ' + discs[0].textContent);
  ok(!/галер|gallery/i.test(doc.body.innerHTML.replace(/\s+/g,' ')), 'ни одного упоминания «галерея» в разметке');
  ok(doc.querySelector('#about h2').textContent.trim()==='Врач, которому доверяют', 'заголовок «О специалисте» обновлён');
  ok(!/\.s-card:hover \.s-card__media img\{transform/.test(doc.querySelector('style').textContent), 'зум картинки на ховере убран');
  ok(doc.querySelector('.promo').textContent.includes('Скидка 30%'), 'промо-плашка в услугах');
  ok(/от 6 000 ₽/.test(doc.querySelector('.s-card__price').textContent), 'цена НЕ изменена: ' + doc.querySelector('.s-card__price').textContent.trim().split('\n')[0]);
  ok(doc.querySelector('#submitBtn').getAttribute('href') && decodeURI(doc.querySelector('#submitBtn').getAttribute('href')).includes('Прошу зафиксировать скидку 30%'), 'скидка в тексте заявки');

  console.log('\nВСЕ ТЕСТЫ ПРОЙДЕНЫ: ' + pass + ' проверок');
  window.close();
})().catch(e => { console.error('\nFAIL:', e.message); process.exit(1); });
